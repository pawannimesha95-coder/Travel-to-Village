TRAVEL TO VILLAGE WEBSITE

Files:
- index.html: complete responsive website
- assets/logo.jpg: your uploaded logo
- assets/cover.jfif: your uploaded cover image

Preview:
Open index.html in a browser.

Publish:
Upload the entire folder to a static hosting service such as Netlify, Vercel, or your web hosting account. Keep the assets folder next to index.html.

Contact details currently used:
Phone / WhatsApp: 0773164386
Email: pawannimesha45@gmail.com

Please verify the email address before publishing. Replace it in index.html if needed.
The tour cards are enquiry templates; no payment or live booking system is connected.
